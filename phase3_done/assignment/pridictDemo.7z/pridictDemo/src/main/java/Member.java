import lombok.Data;

@Data
public class Member {
    private int Year;
    private int startSal;
    private double incrementPer;
    private String incrementFreq;
    private int deductionsAmount;
    private String deductionsFreq;




}
